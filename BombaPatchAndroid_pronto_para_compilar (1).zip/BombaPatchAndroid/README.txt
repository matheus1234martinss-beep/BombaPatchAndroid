BOMBA PATCH DA RESENHA — PROJETO ANDROID

Este é um projeto Android Studio que empacota o aplicativo web do campeonato dentro de um WebView.
A imagem preta e dourada está configurada como ícone do aplicativo.

COMO GERAR O APK:
1. Instale o Android Studio e o Android SDK (API 35).
2. Extraia esta pasta.
3. No Android Studio, escolha Open e selecione a pasta BombaPatchAndroid.
4. Aguarde a sincronização do Gradle.
5. Vá em Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, use o link/aviso Locate para encontrar app-debug.apk.

OBSERVAÇÕES:
- Este pacote é um projeto-fonte, não um APK já compilado.
- A sincronização online em tempo real entre aparelhos não está implementada neste HTML; ela exige backend/banco de dados hospedado.
- Os dados locais dependem do armazenamento do WebView/aparelho.


COMPILAR PELO CELULAR (SEM ANDROID STUDIO)
1. Entre em https://github.com e crie uma conta ou faça login.
2. Crie um repositório novo. Se aparecer a opção, deixe-o privado.
3. Envie os arquivos e pastas deste ZIP para a raiz do repositório, mantendo a pasta BombaPatchAndroid e a pasta .github.
4. Abra a aba Actions e selecione “Compilar APK Android”. Se solicitado, habilite Actions.
5. Toque em “Run workflow” e confirme. Aguarde a execução terminar com marca verde.
6. Abra a execução concluída e baixe o artefato “BombaPatchDaResenha-APK”. Extraia o ZIP baixado para obter app-debug.apk.

OBSERVAÇÃO: este fluxo compila o código existente; não adiciona sincronização online em tempo real entre celulares.
